// 书签管理类
class BookmarkManager {
  constructor() {
    this.bookmarks = [];
    this.sortBy = 'custom'; // 'custom' 或 'frequency'
    this.draggedElement = null;
    this.init();
  }

  async init() {
    await this.loadBookmarks();
    this.bindEvents();
    this.render();
  }

  async loadBookmarks() {
    try {
      const result = await chrome.storage.local.get(['bookmarks']);
      this.bookmarks = result.bookmarks || [];
    } catch (error) {
      console.error('加载书签失败:', error);
      this.bookmarks = [];
    }
  }

  async saveBookmarks() {
    try {
      await chrome.storage.local.set({ bookmarks: this.bookmarks });
    } catch (error) {
      console.error('保存书签失败:', error);
    }
  }

  bindEvents() {
    // 添加书签按钮
    document.getElementById('add-bookmark-btn').addEventListener('click', () => {
      this.showAddModal();
    });

    // 排序按钮
    document.getElementById('sort-custom').addEventListener('click', () => {
      this.setSortMode('custom');
    });

    document.getElementById('sort-frequency').addEventListener('click', () => {
      this.setSortMode('frequency');
    });

    // 弹窗事件
    document.getElementById('cancel-add').addEventListener('click', () => {
      this.hideAddModal();
    });

    document.getElementById('add-bookmark-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.addBookmark();
    });

    // 点击弹窗外部关闭
    document.getElementById('add-modal').addEventListener('click', (e) => {
      if (e.target.id === 'add-modal') {
        this.hideAddModal();
      }
    });
  }

  showAddModal() {
    document.getElementById('add-modal').style.display = 'flex';
    document.getElementById('bookmark-title').focus();
  }

  hideAddModal() {
    document.getElementById('add-modal').style.display = 'none';
    document.getElementById('add-bookmark-form').reset();
  }

  async addBookmark() {
    const title = document.getElementById('bookmark-title').value.trim();
    const url = document.getElementById('bookmark-url').value.trim();

    if (!title || !url) return;

    const bookmark = {
      id: Date.now().toString(),
      title,
      url: this.ensureHttps(url),
      favicon: this.getFaviconUrl(url),
      visitCount: 0,
      lastVisit: 0,
      order: this.bookmarks.length
    };

    this.bookmarks.push(bookmark);
    await this.saveBookmarks();
    this.render();
    this.hideAddModal();
  }

  async deleteBookmark(id) {
    if (confirm('确定要删除这个书签吗？')) {
      const index = this.bookmarks.findIndex(b => b.id === id);
      if (index !== -1) {
        this.bookmarks.splice(index, 1);
        await this.saveBookmarks();
        this.render();
      }
    }
  }

  async openBookmark(bookmark) {
    // 更新访问统计
    bookmark.visitCount++;
    bookmark.lastVisit = Date.now();
    await this.saveBookmarks();

    // 打开链接
    window.open(bookmark.url, '_self');
  }

  setSortMode(mode) {
    this.sortBy = mode;

    // 更新按钮状态
    document.querySelectorAll('.sort-btn').forEach(btn => {
      btn.classList.remove('active');
    });
    document.getElementById(`sort-${mode}`).classList.add('active');

    this.render();
  }

  getSortedBookmarks() {
    const sorted = [...this.bookmarks];
    if (this.sortBy === 'frequency') {
      return sorted.sort((a, b) => b.visitCount - a.visitCount);
    } else {
      return sorted.sort((a, b) => a.order - b.order);
    }
  }

  ensureHttps(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return `https://${url}`;
    }
    return url;
  }

  getFaviconUrl(url) {
    try {
      const domain = new URL(url).hostname;
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
    } catch {
      return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23999"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>';
    }
  }

  formatUrl(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return url;
    }
  }

  // 拖拽功能
  initDragAndDrop(element, bookmark) {
    element.draggable = this.sortBy === 'custom';

    element.addEventListener('dragstart', (e) => {
      if (this.sortBy !== 'custom') {
        e.preventDefault();
        return;
      }
      this.draggedElement = element;
      element.classList.add('dragging');
      e.dataTransfer.effectAllowed = 'move';
      e.dataTransfer.setData('text/html', element.innerHTML);
    });

    element.addEventListener('dragover', (e) => {
      e.preventDefault();
      e.dataTransfer.dropEffect = 'move';
    });

    element.addEventListener('drop', async (e) => {
      e.preventDefault();

      if (!this.draggedElement || this.draggedElement === element) return;

      const draggedId = this.draggedElement.dataset.id;
      const targetId = element.dataset.id;

      const draggedIndex = this.bookmarks.findIndex(b => b.id === draggedId);
      const targetIndex = this.bookmarks.findIndex(b => b.id === targetId);

      if (draggedIndex !== -1 && targetIndex !== -1) {
        const [draggedBookmark] = this.bookmarks.splice(draggedIndex, 1);
        this.bookmarks.splice(targetIndex, 0, draggedBookmark);

        // 更新order值
        this.bookmarks.forEach((bookmark, index) => {
          bookmark.order = index;
        });

        await this.saveBookmarks();
        this.render();
      }
    });

    element.addEventListener('dragend', () => {
      element.classList.remove('dragging');
      this.draggedElement = null;
    });
  }

  render() {
    const container = document.getElementById('bookmarks-grid');
    const sortedBookmarks = this.getSortedBookmarks();

    container.innerHTML = '';

    if (sortedBookmarks.length === 0) {
      container.innerHTML = `
        <div style="grid-column: 1 / -1; text-align: center; padding: 3rem; color: #666;">
          <p style="font-size: 1.2rem; margin-bottom: 1rem;">还没有书签</p>
          <p style="color: #999;">点击"添加书签"按钮开始添加你喜欢的网站</p>
        </div>
      `;
      return;
    }

    sortedBookmarks.forEach(bookmark => {
      const card = document.createElement('div');
      card.className = 'bookmark-card';
      card.dataset.id = bookmark.id;

      card.innerHTML = `
        <div class="bookmark-favicon">
          <img src="${bookmark.favicon}" alt="${bookmark.title}"
               onerror="this.src='data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 24 24%22 fill=%22%23999%22><path d=%22M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5%22/></svg>'">
        </div>
        <div class="bookmark-info">
          <h3 class="bookmark-title">${bookmark.title}</h3>
          <p class="bookmark-url">${this.formatUrl(bookmark.url)}</p>
        </div>
        <div class="bookmark-actions">
          <button class="delete-btn">×</button>
        </div>
      `;

      // 绑定事件
      card.addEventListener('click', (e) => {
        if (!e.target.classList.contains('delete-btn')) {
          this.openBookmark(bookmark);
        }
      });

      card.querySelector('.delete-btn').addEventListener('click', (e) => {
        e.stopPropagation();
        this.deleteBookmark(bookmark.id);
      });

      // 初始化拖拽
      this.initDragAndDrop(card, bookmark);

      container.appendChild(card);
    });
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  new BookmarkManager();
});