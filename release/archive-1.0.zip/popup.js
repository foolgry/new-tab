// Popup管理类
class PopupManager {
  constructor() {
    this.currentPage = null;
    this.init();
  }

  async init() {
    await this.getCurrentPage();
    this.bindEvents();
  }

  async getCurrentPage() {
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab && tab.url && tab.title) {
        const url = new URL(tab.url);

        // 排除Chrome内部页面
        if (url.protocol.startsWith('chrome://') || url.protocol === 'chrome-extension://') {
          document.getElementById('current-page').style.display = 'none';
          return;
        }

        this.currentPage = {
          title: tab.title,
          url: tab.url,
          favicon: tab.favIconUrl || this.getFaviconUrl(tab.url)
        };

        // 更新UI
        document.getElementById('page-favicon').src = this.currentPage.favicon;
        document.getElementById('page-title').textContent = this.currentPage.title;
        document.getElementById('page-url').textContent = this.formatUrl(this.currentPage.url);
        document.getElementById('bookmark-title').value = this.currentPage.title;
        document.getElementById('bookmark-url').value = this.currentPage.url;
      } else {
        document.getElementById('current-page').style.display = 'none';
      }
    } catch (error) {
      console.error('获取当前页面信息失败:', error);
      document.getElementById('current-page').style.display = 'none';
    }
  }

  bindEvents() {
    // 表单提交
    document.getElementById('add-form').addEventListener('submit', (e) => {
      e.preventDefault();
      this.addToBookmarks();
    });

    // 查看所有书签
    document.getElementById('view-bookmarks').addEventListener('click', () => {
      this.openBookmarksPage();
    });
  }

  async addToBookmarks() {
    const title = document.getElementById('bookmark-title').value.trim();
    const url = document.getElementById('bookmark-url').value.trim();
    const submitBtn = document.getElementById('submit-btn');

    if (!title || !url) return;

    submitBtn.disabled = true;
    submitBtn.textContent = '添加中...';

    try {
      const bookmarks = await this.loadBookmarks();

      // 检查是否已存在相同URL的书签
      const existingBookmark = bookmarks.find(b => b.url === this.ensureHttps(url));
      if (existingBookmark) {
        this.showMessage('该书签已存在！', 'error');
        return;
      }

      const bookmark = {
        id: Date.now().toString(),
        title,
        url: this.ensureHttps(url),
        favicon: this.getFaviconUrl(url),
        visitCount: 0,
        lastVisit: 0,
        order: bookmarks.length
      };

      bookmarks.push(bookmark);
      await this.saveBookmarks(bookmarks);

      this.showMessage('书签添加成功！', 'success');

      // 2秒后关闭弹窗
      setTimeout(() => {
        window.close();
      }, 2000);

    } catch (error) {
      console.error('添加书签失败:', error);
      this.showMessage('添加失败，请重试！', 'error');
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = '添加到书签';
    }
  }

  async loadBookmarks() {
    try {
      const result = await chrome.storage.local.get(['bookmarks']);
      return result.bookmarks || [];
    } catch (error) {
      console.error('加载书签失败:', error);
      return [];
    }
  }

  async saveBookmarks(bookmarks) {
    try {
      await chrome.storage.local.set({ bookmarks });
    } catch (error) {
      console.error('保存书签失败:', error);
      throw error;
    }
  }

  showMessage(text, type = 'success') {
    const messageEl = document.getElementById('message');
    messageEl.textContent = text;
    messageEl.className = `message ${type}`;
    messageEl.style.display = 'block';

    // 3秒后自动隐藏
    setTimeout(() => {
      messageEl.style.display = 'none';
    }, 3000);
  }

  ensureHttps(url) {
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      return `https://${url}`;
    }
    return url;
  }

  getFaviconUrl(url) {
    try {
      const domain = new URL(url).hostname;
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=64`;
    } catch {
      return 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23999"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>';
    }
  }

  formatUrl(url) {
    try {
      return new URL(url).hostname;
    } catch {
      return url;
    }
  }

  openBookmarksPage() {
    chrome.tabs.create({ url: 'chrome://newtab' });
    window.close();
  }
}

// 页面加载完成后初始化
document.addEventListener('DOMContentLoaded', () => {
  new PopupManager();
});